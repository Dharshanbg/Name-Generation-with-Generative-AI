#include<stdio.h>
   void main()
   {
    char *p;
    int ch=48;
    p=ch;
    printf("%d",p);
    }